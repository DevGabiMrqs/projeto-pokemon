url = "https://bulbapedia.bulbagarden.net/wiki/Vulpix_(Pok%C3%A9mon)"
const btnVerSite = document.querySelector('.btn-ver-mais');
const selectGolpes = document.querySelector('.lista-golpes');
const btnAdicionar = document.querySelector('.btn-adicionar');




function verSite() {
    let ver = window.open(url, '_blank')
}

let moveSelecionado = '';
let moveSet = [];
let golpesLista = ['Flash Fire','Drought', 'Amber','Tackle','Bite'];

function levarGolpes(){
    for (let i = 0; i < golpesLista.length; i++) {
        const option = document.createElement('option')
        option.innerText = `${golpesLista[i]}`
        option.id = `${golpesLista[i]}`
        selectGolpes.appendChild(option)
    }
}

levarGolpes();


btnAdicionar.addEventListener("click", adicionar)


function adicionar() {
moveSelecionado = selectGolpes.value

let li = document.createElement('li')
li.id = moveSelecionado
li.innerHTML = `${moveSelecionado} <button id="del${moveSelecionado}">Deletar</button>`

document.getElementsByClassName('container-golpes').appendChild(li)

document.getElementById(`del${moveSelecionado}`).addEventListener("click", deletaGolpes)

}

function deletaGolpes()




//else - nenhum golpe adicionado ao moveset